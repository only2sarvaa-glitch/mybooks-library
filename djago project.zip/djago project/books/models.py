from django.db import models  # type: ignore[reportMissingModuleSource]

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
